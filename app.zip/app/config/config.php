<?php

    define("ASSETSURL", "http://localhost/Responsi_2_TheBoys/public/");
    define("ASSETSCSS", "http://localhost/Responsi_2_TheBoys/public/css/");
    define("ASSETSJS", "http://localhost/Responsi_2_TheBoys/public/js/");
    define("ASSETSIMG", "http://localhost/Responsi_2_TheBoys/public/img/");
    define("BASEURL", "http://localhost/Responsi_2_TheBoys/public/");
    define("VIEWSURL", "http://localhost/Responsi_2_TheBoys/app/views/");
    define("DB_HOST", "localhost");
    define("DB_USER", "root");
    define("DB_PASS", "");
    define("DB_NAME", "theboysweb");
    define("UPLOADS", "http://localhost/Responsi_2_TheBoys/public/uploads/");
    define("FORCED_REDIRECT", "http://localhost/Responsi_2_TheBoys/app/views/The_Boys/");